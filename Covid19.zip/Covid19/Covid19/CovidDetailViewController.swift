//
//  CovidDetailViewController.swift
//  Covid19
//
//  Created by Chrissy Lee on 2022/04/23.
//

import UIKit

class CovidDetailViewController: UITableViewController {

    
    @IBOutlet weak var regionalOutbreakCell: UITableViewCell!
    @IBOutlet weak var percentageCell: UITableViewCell!
    @IBOutlet weak var deathCell: UITableViewCell!
    @IBOutlet weak var recoveredCell: UITableViewCell!
    @IBOutlet weak var totalCaseCell: UITableViewCell!
    @IBOutlet weak var newCaseCell: UITableViewCell!
    @IBOutlet weak var overseasInflowCell: UITableViewCell!
    var covidOverview : CovidOverview?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.configureView()
    }
    
    func configureView(){
        guard let covidOverview = self.covidOverview else {
            return
        }
        self.title = covidOverview.countryName
        self.newCaseCell.detailTextLabel?.text = "\(covidOverview.newCase)"
        self.totalCaseCell.detailTextLabel?.text = "\(covidOverview.totalCase)"
        self.recoveredCell.detailTextLabel?.text = "\(covidOverview.recovered)"
        self.deathCell.detailTextLabel?.text =  "\(covidOverview.death)"
        self.percentageCell.detailTextLabel?.text =  "\(covidOverview.percentage)"
        self.overseasInflowCell.detailTextLabel?.text =  "\(covidOverview.newFcase)"
        self.regionalOutbreakCell.detailTextLabel?.text =  "\(covidOverview.newCcase)"

    }


  

}
